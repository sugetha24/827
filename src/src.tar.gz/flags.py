'''
Created on Sep 30, 2012

@author: sugethk
'''
flags=[0]*32
#flags[0]=0
def set_flags(pos,status):
    flags[pos]=status